# PySO
Particle swarm optimizer

Currently under development. 
